﻿param([string]$PythonPath = "python", [int]$Port = 8000)
$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot
$env:PYTHONPATH = Join-Path $PSScriptRoot "src"
& $PythonPath -B -m mm_jailbreak_guard web --config candidate/learned_fusion.json --replay-manifest candidate/inputs/manifests/validation.jsonl --image-evidence candidate/inputs/B/image_evidence.validation.jsonl --text-evidence candidate/inputs/C/validation.jsonl --records outputs/demo_records.jsonl --port $Port
exit $LASTEXITCODE
